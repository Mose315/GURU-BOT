let handler = async m =>
  m.reply(
    `

≡  *GURU  ┃ ᴮᴼᵀ*   GROUPS

─────────────
▢ Join public bot group and support
https://chat.whatsapp.com/F3sB3pR3tClBvVmlIkqDJp

▢ Group 2
https://chat.whatsapp.com/LwLQab5mZVW6WWRbBPnDGC

▢ Group 3
https://chat.whatsapp.com/Jn9qVerYN6Q1L0vlVFe2XL

─────────────
≡ Disabled links? enter here! 

▢ Group WhatsApp 
 https://chat.whatsapp.com/F3sB3pR3tClBvVmlIkqDJp
─────────────
▢ *Owner Telegram*
 https://t.me/i_want_to_be_isekaied

▢ *YouTube*
• https://www.youtube.com/@Asliguru


`.trim()
  )
handler.help = ['gpguru']
handler.tags = ['main']
handler.command = ['groups', 'groupguru', 'gugp', 'ggp', 'gpguru']

export default handler
