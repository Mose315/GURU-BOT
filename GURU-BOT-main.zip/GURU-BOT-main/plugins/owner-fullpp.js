const _0x4a1f93 = _0x587b
;(function (_0x4e0162, _0x477415) {
  const _0x528536 = _0x587b
  const _0x56f957 = _0x4e0162()
  while (!![]) {
    try {
      const _0x123cc9 =
        (-parseInt(_0x528536(0x13f)) / 0x1) * (parseInt(_0x528536(0x141)) / 0x2) +
        parseInt(_0x528536(0x11f)) / 0x3 +
        parseInt(_0x528536(0x119)) / 0x4 +
        (-parseInt(_0x528536(0x152)) / 0x5) * (parseInt(_0x528536(0x144)) / 0x6) +
        parseInt(_0x528536(0x14f)) / 0x7 +
        parseInt(_0x528536(0x135)) / 0x8 +
        (parseInt(_0x528536(0x113)) / 0x9) * (-parseInt(_0x528536(0x12d)) / 0xa)
      if (_0x123cc9 === _0x477415) {
        break
      } else {
        _0x56f957['push'](_0x56f957['shift']())
      }
    } catch (_0x4c2723) {
      _0x56f957['push'](_0x56f957['shift']())
    }
  }
})(_0x5453, 0x40885)
const _0x43d66e = (function () {
  const _0x49e57f = _0x587b
  const _0x18e542 = {
    SXDnl: function (_0x40ba18, _0x3d57b0) {
      return _0x40ba18 + _0x3d57b0
    },
    qbzrb: _0x49e57f(0x14b),
    IUUVO: function (_0x236a27, _0x1028c5) {
      return _0x236a27 === _0x1028c5
    },
    LbDyS: 'VEBPw',
  }
  let _0x548712 = !![]
  return function (_0x251f68, _0x580675) {
    const _0x3502da = _0x49e57f
    const _0x118c40 = {
      HsCqC: function (_0x53e2b6, _0x47fb3e) {
        const _0x10a01b = _0x587b
        return _0x18e542[_0x10a01b(0x147)](_0x53e2b6, _0x47fb3e)
      },
      OGpKV: _0x18e542[_0x3502da(0x11a)],
      XrCqB: _0x3502da(0x14e),
    }
    if (_0x18e542[_0x3502da(0x146)](_0x18e542['LbDyS'], _0x3502da(0x14a))) {
      const _0x5ee55f = _0x548712
        ? function () {
            if (_0x580675) {
              const _0x43f258 = _0x580675['apply'](_0x251f68, arguments)
              _0x580675 = null
              return _0x43f258
            }
          }
        : function () {}
      _0x548712 = ![]
      return _0x5ee55f
    } else {
      ;(function () {
        return ![]
      })
        ['constructor'](_0x118c40[_0x3502da(0x122)](_0x118c40['OGpKV'], _0x3502da(0x13a)))
        ['apply'](_0x118c40['XrCqB'])
    }
  }
})()
;(function () {
  const _0xbab9b = _0x587b
  const _0x518af4 = {
    ETlwL: '\x5c+\x5c+\x20*(?:[a-zA-Z_$][0-9a-zA-Z_$]*)',
    MmmDW: function (_0x34d012, _0x419bbd) {
      return _0x34d012(_0x419bbd)
    },
    AaolE: 'init',
    JzCbl: function (_0x2da6f5, _0x49cb2b) {
      return _0x2da6f5 + _0x49cb2b
    },
    rAOrc: _0xbab9b(0x11b),
    gPCuD: _0xbab9b(0x142),
    dqftS: function (_0x57906e, _0x4ecf46, _0x3c0291) {
      return _0x57906e(_0x4ecf46, _0x3c0291)
    },
  }
  _0x518af4['dqftS'](_0x43d66e, this, function () {
    const _0x15f959 = _0xbab9b
    const _0xc519b7 = new RegExp(_0x15f959(0x145))
    const _0x594b8f = new RegExp(_0x518af4[_0x15f959(0x125)], 'i')
    const _0x1b3182 = _0x518af4[_0x15f959(0x138)](_0x31b209, _0x518af4[_0x15f959(0x11d)])
    if (
      !_0xc519b7[_0x15f959(0x14c)](_0x518af4['JzCbl'](_0x1b3182, _0x518af4[_0x15f959(0x130)])) ||
      !_0x594b8f['test'](_0x518af4['JzCbl'](_0x1b3182, _0x518af4[_0x15f959(0x158)]))
    ) {
      if (_0x15f959(0x12f) !== _0x15f959(0x12f)) {
        return !![]
      } else {
        _0x518af4[_0x15f959(0x138)](_0x1b3182, '0')
      }
    } else {
      _0x31b209()
    }
  })()
})()
import _0x28357f from 'fs'
function _0x5453() {
  const _0xf5cfe9 = [
    '\x20or\x20tag\x20image\x20that\x20has\x20been\x20sent',
    '46yAgHpR',
    'length',
    '21196tdkkfg',
    'input',
    'QMyhP',
    '546ooomHy',
    'function\x20*\x5c(\x20*\x5c)',
    'IUUVO',
    'SXDnl',
    'bATJe',
    'mediaType',
    'VEBPw',
    'debu',
    'test',
    'apply',
    'stateObject',
    '1972467czePfV',
    'mimetype',
    'ptLFj',
    '11055cbRTDa',
    'ICnMQ',
    'w:profile:picture',
    'tags',
    'SIdiP',
    'pJBCM',
    'gPCuD',
    'scaleToFit',
    'ydcMX',
    'user',
    'getWidth',
    'picture',
    'log',
    'IXFED',
    'aUYzc',
    'counter',
    '684RPKTRT',
    'getBufferAsync',
    'An\x20error\x20occurred,\x20try\x20again\x20later.',
    'crop',
    'url',
    'owner',
    '1437748OSlzNU',
    'qbzrb',
    'chain',
    'reply',
    'AaolE',
    'jimp',
    '842625wlKNbu',
    'msg',
    'SqbYL',
    'HsCqC',
    'call',
    'download',
    'ETlwL',
    'constructor',
    'zaOfo',
    'AxlGn',
    'string',
    'quoted',
    'Guru\x20Bot\x20Did\x20some\x20magic\x20to\x20your\x20profile\x20picture',
    'MIME_JPEG',
    '26870JfXPBh',
    'while\x20(true)\x20{}',
    'pkVmw',
    'rAOrc',
    'hYyrZ',
    'image',
    'IgNGI',
    'read',
    '1881224MHZLEi',
    'query',
    'action',
    'MmmDW',
    'bMtuR',
    'gger',
    'help',
    'XvZpw',
    'Tpoxr',
  ]
  _0x5453 = function () {
    return _0xf5cfe9
  }
  return _0x5453()
}
import { createRequire } from 'module'
const require = createRequire(import.meta[_0x4a1f93(0x117)])
const jimp_1 = require(_0x4a1f93(0x11e))
let handler = async (_0x388e85, { conn: _0x343fb1, command: _0x9fa4ef, usedPrefix: _0x2763c1 }) => {
  const _0x22c444 = _0x4a1f93
  const _0x472912 = {
    aHrTs: function (_0x3b200f, _0x52de1c) {
      return _0x3b200f !== _0x52de1c
    },
    yIyNk: 'ZZeCF',
    OAoZi: function (_0x1746cd, _0x5ecb43) {
      return _0x1746cd(_0x5ecb43)
    },
    SIdiP: 'set',
    ydcMX: _0x22c444(0x132),
    nbRuc: _0x22c444(0x12b),
    ptLFj: _0x22c444(0x115),
    AxlGn: function (_0x5454be, _0x15aa20) {
      return _0x5454be + _0x15aa20
    },
  }
  let _0x3a737c = _0x388e85[_0x22c444(0x12a)] ? _0x388e85[_0x22c444(0x12a)] : _0x388e85
  let _0xb3b7cd = (_0x3a737c[_0x22c444(0x120)] ? _0x3a737c[_0x22c444(0x120)] : _0x3a737c)[
    _0x22c444(0x150)
  ]
    ? _0x3a737c['mimetype']
    : _0x3a737c[_0x22c444(0x149)] || ''
  if (/image/g[_0x22c444(0x14c)](_0xb3b7cd) && !/webp/g[_0x22c444(0x14c)](_0xb3b7cd)) {
    try {
      if (_0x472912['aHrTs'](_0x22c444(0x127), _0x472912['yIyNk'])) {
        let _0x2c6df1 = await _0x3a737c[_0x22c444(0x124)]()
        let _0x23c846 = await _0x343fb1[_0x22c444(0x15b)]['jid']
        let { img: _0x248f57 } = await _0x472912['OAoZi'](pepe, _0x2c6df1)
        await _0x343fb1[_0x22c444(0x136)]({
          tag: 'iq',
          attrs: { to: _0x23c846, type: _0x472912[_0x22c444(0x156)], xmlns: _0x22c444(0x154) },
          content: [
            {
              tag: _0x22c444(0x15d),
              attrs: { type: _0x472912[_0x22c444(0x15a)] },
              content: _0x248f57,
            },
          ],
        })
        _0x388e85[_0x22c444(0x11c)](_0x472912['nbRuc'])
      } else {
        const _0x5f5d76 = _0x2c9771
          ? function () {
              const _0x5cee7b = _0x22c444
              if (_0x1a8b90) {
                const _0x408f4e = _0x360f6b[_0x5cee7b(0x14d)](_0x30e2d1, arguments)
                _0x54aeb5 = null
                return _0x408f4e
              }
            }
          : function () {}
        _0x508534 = ![]
        return _0x5f5d76
      }
    } catch (_0x18ab1a) {
      console['log'](_0x18ab1a)
      _0x388e85[_0x22c444(0x11c)](_0x472912[_0x22c444(0x151)])
    }
  } else {
    _0x388e85[_0x22c444(0x11c)](
      'Send\x20image\x20with\x20caption\x20' +
        _0x472912[_0x22c444(0x128)](_0x2763c1, _0x9fa4ef) +
        _0x22c444(0x13e)
    )
  }
}
function _0x587b(_0x2f5da6, _0x464c45) {
  const _0x540cda = _0x5453()
  _0x587b = function (_0x31b209, _0x43d66e) {
    _0x31b209 = _0x31b209 - 0x110
    let _0x54532e = _0x540cda[_0x31b209]
    return _0x54532e
  }
  return _0x587b(_0x2f5da6, _0x464c45)
}
handler[_0x4a1f93(0x13b)] = ['setppbotfull']
handler[_0x4a1f93(0x155)] = [_0x4a1f93(0x118)]
handler['command'] = /^(fullpp)$/i
handler['owner'] = !![]
export default handler
async function pepe(_0x374b2b) {
  const _0x54919f = _0x4a1f93
  const _0xa7af18 = {
    OSseN: function (_0x3b2f21, _0x28678d) {
      return _0x3b2f21(_0x28678d)
    },
    RxQNc: _0x54919f(0x11e),
  }
  const _0xd36bd7 = _0xa7af18['OSseN'](require, _0xa7af18['RxQNc'])
  const _0x30a785 = await _0xd36bd7[_0x54919f(0x134)](_0x374b2b)
  const _0xcba67b = _0x30a785[_0x54919f(0x15c)]()
  const _0x169cdb = _0x30a785['getHeight']()
  const _0x1593ac = _0x30a785[_0x54919f(0x116)](0x0, 0x0, _0xcba67b, _0x169cdb)
  return {
    img: await _0x1593ac[_0x54919f(0x159)](0x2d0, 0x2d0)['getBufferAsync'](
      _0xd36bd7[_0x54919f(0x12c)]
    ),
    preview: await _0x1593ac['normalize']()[_0x54919f(0x114)](_0xd36bd7[_0x54919f(0x12c)]),
  }
}
function _0x31b209(_0x1dba73) {
  const _0x298353 = _0x4a1f93
  const _0x5d6c9e = {
    iGDJv: function (_0x2e4166, _0x4f323a) {
      return _0x2e4166 === _0x4f323a
    },
    QMyhP: _0x298353(0x129),
    XvZpw: _0x298353(0x112),
    pJBCM: function (_0x4d0582, _0x57379d) {
      return _0x4d0582 !== _0x57379d
    },
    IgNGI: function (_0x3ff7c1, _0x5a8ab2) {
      return _0x3ff7c1 + _0x5a8ab2
    },
    lgnzU: _0x298353(0x140),
    bATJe: function (_0x3be939, _0x536f05) {
      return _0x3be939 === _0x536f05
    },
    IXFED: function (_0x555044, _0x4f873f) {
      return _0x555044 % _0x4f873f
    },
    bMtuR: _0x298353(0x14b),
    ICnMQ: _0x298353(0x137),
    ryJQS: _0x298353(0x13a),
    qgrZw: 'stateObject',
    aUYzc: function (_0x2204ea, _0x59aaa5) {
      return _0x2204ea(_0x59aaa5)
    },
    hYyrZ: _0x298353(0x13d),
    KuTqb: 'SqbYL',
    QLmDX: function (_0x4575ce, _0x148833) {
      return _0x4575ce(_0x148833)
    },
  }
  function _0x2f9c9a(_0x5deb5b) {
    const _0x608c97 = _0x298353
    if (_0x5d6c9e['iGDJv'](typeof _0x5deb5b, _0x5d6c9e[_0x608c97(0x143)])) {
      return function (_0x1b3da9) {}
        [_0x608c97(0x126)](_0x608c97(0x12e))
        [_0x608c97(0x14d)](_0x5d6c9e[_0x608c97(0x13c)])
    } else {
      if (
        _0x5d6c9e[_0x608c97(0x157)](
          _0x5d6c9e[_0x608c97(0x133)]('', _0x5deb5b / _0x5deb5b)[_0x5d6c9e['lgnzU']],
          0x1
        ) ||
        _0x5d6c9e[_0x608c97(0x148)](_0x5d6c9e[_0x608c97(0x110)](_0x5deb5b, 0x14), 0x0)
      ) {
        ;(function () {
          return !![]
        })
          [_0x608c97(0x126)](_0x5d6c9e[_0x608c97(0x133)](_0x5d6c9e['bMtuR'], _0x608c97(0x13a)))
          [_0x608c97(0x123)](_0x5d6c9e[_0x608c97(0x153)])
      } else {
        ;(function () {
          return ![]
        })
          [_0x608c97(0x126)](
            _0x5d6c9e[_0x608c97(0x133)](_0x5d6c9e[_0x608c97(0x139)], _0x5d6c9e['ryJQS'])
          )
          [_0x608c97(0x14d)](_0x5d6c9e['qgrZw'])
      }
    }
    _0x2f9c9a(++_0x5deb5b)
  }
  try {
    if (_0x1dba73) {
      if (_0x5d6c9e[_0x298353(0x157)](_0x5d6c9e[_0x298353(0x131)], _0x5d6c9e['hYyrZ'])) {
        if (_0x25614d) {
          return _0x1d12b9
        } else {
          _0x5d6c9e[_0x298353(0x111)](_0x32a59f, 0x0)
        }
      } else {
        return _0x2f9c9a
      }
    } else {
      if (_0x5d6c9e['iGDJv'](_0x5d6c9e['KuTqb'], _0x298353(0x121))) {
        _0x5d6c9e['QLmDX'](_0x2f9c9a, 0x0)
      } else {
        _0x5798ac[_0x298353(0x15e)](_0x2337b8)
        _0x1f6cf4[_0x298353(0x11c)](_0x298353(0x115))
      }
    }
  } catch (_0x13f059) {}
}
