const _0x19dd6a = _0x379e
;(function (_0x29da58, _0x2edd40) {
  const _0x384a5b = _0x379e
  const _0x170fe3 = _0x29da58()
  while (!![]) {
    try {
      const _0x128782 =
        -parseInt(_0x384a5b(0x11a)) / 0x1 +
        (parseInt(_0x384a5b(0x12d)) / 0x2) * (parseInt(_0x384a5b(0x127)) / 0x3) +
        (-parseInt(_0x384a5b(0x114)) / 0x4) * (parseInt(_0x384a5b(0x11f)) / 0x5) +
        (parseInt(_0x384a5b(0x122)) / 0x6) * (parseInt(_0x384a5b(0x116)) / 0x7) +
        parseInt(_0x384a5b(0x11b)) / 0x8 +
        (parseInt(_0x384a5b(0x10f)) / 0x9) * (-parseInt(_0x384a5b(0x12c)) / 0xa) +
        -parseInt(_0x384a5b(0x110)) / 0xb
      if (_0x128782 === _0x2edd40) {
        break
      } else {
        _0x170fe3['push'](_0x170fe3['shift']())
      }
    } catch (_0x134cca) {
      _0x170fe3['push'](_0x170fe3['shift']())
    }
  }
})(_0xb1b4, 0xe10a5)
import _0x406196 from 'node-fetch'
let handler = async (
  _0x47a04a,
  { conn: _0x4a7b4b, args: _0x1facfe, usedPrefix: _0x2fa54b, command: _0x104623, text: _0x53666f }
) => {
  const _0x2ff938 = _0x379e
  if (!_0x53666f && !(_0x47a04a['quoted'] && _0x47a04a[_0x2ff938(0x124)][_0x2ff938(0x123)])) {
    throw _0x2ff938(0x12b)
  }
  if (!_0x53666f && _0x47a04a[_0x2ff938(0x124)] && _0x47a04a[_0x2ff938(0x124)][_0x2ff938(0x123)]) {
    _0x53666f = _0x47a04a['quoted']['text']
  }
  _0x47a04a[_0x2ff938(0x126)](_0x2ff938(0x118))
  _0x47a04a[_0x2ff938(0x112)]('🤔')
  const _0x16d711 = encodeURIComponent(_0x53666f)
  let _0x2b4311 = await Bing(_0x16d711)
  if (!_0x2b4311) {
    throw new Error(_0x2ff938(0x125))
  }
  await _0x4a7b4b['reply'](_0x47a04a[_0x2ff938(0x129)], _0x2b4311[_0x2ff938(0x12a)], _0x47a04a)
}
handler[_0x19dd6a(0x119)] = [_0x19dd6a(0x117)]
function _0xb1b4() {
  const _0x113865 = [
    'quoted',
    'No\x20valid\x20JSON\x20response\x20from\x20Bing\x20',
    'reply',
    '3jHchyf',
    'json',
    'chat',
    'result',
    'Please\x20provide\x20some\x20text\x20or\x20quote\x20a\x20message\x20to\x20get\x20a\x20response.',
    '10jgaojq',
    '1224668cTLgnn',
    '721575eyMVOi',
    '1385901iFYTlu',
    'Mozilla/5.0\x20(Windows\x20NT\x2010.0;\x20WOW64)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/91.0.4472.114\x20Safari/537.36',
    'react',
    'command',
    '8jewvCy',
    'get',
    '21RIoHpz',
    'bing',
    'thinking...',
    'help',
    '609992HifjSS',
    '1202496XfQOBE',
    'LBSIU',
    'https://aemt.me/bingai?text=',
    'application/x-www-form-urlencoded;charset=UTF-8',
    '2158655POTZKQ',
    'tags',
    'pQJyL',
    '3677478chKueI',
    'text',
  ]
  _0xb1b4 = function () {
    return _0x113865
  }
  return _0xb1b4()
}
handler[_0x19dd6a(0x120)] = ['ai']
handler[_0x19dd6a(0x113)] = /^(bing)$/i
export default handler
async function Bing(_0x2f3bdc) {
  const _0x55d2cd = _0x19dd6a
  const _0x2478a7 = {
    LBSIU: _0x55d2cd(0x111),
    pQJyL: _0x55d2cd(0x11e),
    QJeWy: function (_0x4dedde, _0x450c3c, _0x5d6b86) {
      return _0x4dedde(_0x450c3c, _0x5d6b86)
    },
  }
  const _0x1ea7d6 = {
    'User-Agent': _0x2478a7[_0x55d2cd(0x11c)],
    'Content-Type': _0x2478a7[_0x55d2cd(0x121)],
  }
  const _0x4c0ac0 = await _0x2478a7['QJeWy'](_0x406196, _0x55d2cd(0x11d) + _0x2f3bdc, {
    method: _0x55d2cd(0x115),
    headers: _0x1ea7d6,
  })
  const _0x497387 = await _0x4c0ac0[_0x55d2cd(0x128)]()
  return _0x497387
}
function _0x379e(_0x21779b, _0x4c8613) {
  const _0xb1b452 = _0xb1b4()
  _0x379e = function (_0x379e31, _0x17aa74) {
    _0x379e31 = _0x379e31 - 0x10f
    let _0x37d2d9 = _0xb1b452[_0x379e31]
    return _0x37d2d9
  }
  return _0x379e(_0x21779b, _0x4c8613)
}
